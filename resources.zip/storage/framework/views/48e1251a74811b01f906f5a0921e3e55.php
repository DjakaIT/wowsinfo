<?php
  use App\Helpers\FrontendHelper;
?>


<?php $__env->startSection('metaTitle', $metaSite['metaTitle']); ?>
<?php $__env->startSection('metaDescription', $metaSite['metaDescription']); ?>
<?php $__env->startSection('metaKeywords', $metaSite['metaKeywords']); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-padding">
        <!-- Player info -->
        <p class="player-title"><?php echo e($playerInfo['name']); ?>

        <p v-if="playerInfo.clanName != ''" class="pointer gray-link">
            <?php echo e($playerInfo['clanName']); ?>

        </p>
        </p>
        <p class="player-info">Created at: <?php echo e($playerInfo['createdAt']); ?></p>
        <!-- ### Player info -->
        <!-- Player statistics -->
        <!-- <div v-if="playerStatistics === null">Loading</div> -->
        <div class="shadow4 mb-40">
            <table class="table table-striped table-bordered customRedefine playerTable">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="border-b">Stats</th>
                        <th class="border-b">Overall</th>
                        <th class="border-b">Last Day</th>
                        <th class="border-b">Last 7 days</th>
                        <th class="border-b">Last month</th>
                    </tr>
                </thead>
                <tbody>
                    <tr class="border-b">
                        <td class="py-2 px-4">Battles</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['battles'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['battles'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['battles'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['battles'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Wins</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['wins'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['wins'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['wins'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['wins'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Tier</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['tier'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['tier'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['tier'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['tier'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Survived</td>
                        <td class="py-2 px-4">
                            <?php echo e(isset($playerStatistics['overall']['survived']) ? round($playerStatistics['overall']['survived'], 2) . '%' : 'N/A'); ?>

                        </td>
                        <td class="py-2 px-4">
                            <?php echo e(isset($playerStatistics['lastDay']['survived']) ? round($playerStatistics['lastDay']['survived'], 2) . '%' : 'N/A'); ?>

                        </td>
                        <td class="py-2 px-4">
                            <?php echo e(isset($playerStatistics['lastWeek']['survived']) ? round($playerStatistics['lastWeek']['survived'], 2) . '%' : 'N/A'); ?>

                        </td>
                        <td class="py-2 px-4">
                            <?php echo e(isset($playerStatistics['lastMonth']['survived']) ? round($playerStatistics['lastMonth']['survived'], 2) . '%' : 'N/A'); ?>

                        </td>
                    <tr class="border-b">
                        <td class="py-2 px-4">Damage</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['damage'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['damage'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['damage'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['damage'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Frags</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['frags'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['frags'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['frags'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['frags'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Spotted</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['spotted'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['spotted'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['spotted'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['spotted'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Experience</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['xp'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['xp'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['xp'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['xp'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Capture</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['capture'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['capture'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['capture'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['capture'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">Defend</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['defend']  ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['defend']  ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['defend']  ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['defend']  ?? 'N/A'); ?></td>
                    </tr>
                    <tr class="border-b">
                        <td class="py-2 px-4">PR</td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['overall']['pr'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastDay']['pr']  ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastWeek']['pr'] ?? 'N/A'); ?></td>
                        <td class="py-2 px-4"><?php echo e($playerStatistics['lastMonth']['pr']  ?? 'N/A'); ?></td>
                    </tr> 
                    <tr class="border-b">
                        <td class="py-2 px-4">WN8</td>
                        <td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($playerStatistics['overall']['wn8'] ?? 0)); ?>">
                            <?php echo e($playerStatistics['overall']['wn8'] ?? 'N/A'); ?>

                        </td>                        
                        <td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($playerStatistics['lastDay']['wn8'] ?? 0)); ?>">
                            <?php echo e($playerStatistics['lastDay']['wn8'] ?? 'N/A'); ?>

                        </td>
                        <td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($playerStatistics['lastWeek']['wn8'] ?? 0)); ?>">
                            <?php echo e($playerStatistics['lastWeek']['wn8'] ?? 'N/A'); ?>

                        </td>
                        <td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($playerStatistics['lastMonth']['wn8'] ?? 0)); ?>">
                            <?php echo e($playerStatistics['lastMonth']['wn8'] ?? 'N/A'); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!-- ### Player statistics -->
        <!-- Player vehicles -->
        <!-- <div v-if="playerVehicles.length === 0">Loading</div> -->
        <div class="shadow4 table-container">
            <table class="table table-striped table-bordered customRedefine playerTable">
                <thead>
                    <tr class="bg-gray-100 text-left">
                        <th class="border-b">Nation</th>
                        <th class="border-b">Name</th>
                        <th class="border-b">Tier</th>
                        <th class="border-b">Battles</th>
                        <th class="border-b">Frags</th>
                        <th class="border-b">Damage</th>
                        <th class="border-b">Wins</th>
                        <th class="border-b">WN8</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $playerVehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b">
                            <td class="py-2 px-4"><?php echo e($vehicle['nation']); ?></td>
                            <td class="py-2 px-4"><?php echo e($vehicle['name']); ?></td>
                            <td class="py-2 px-4"><?php echo e($vehicle['tier']); ?></td>
                            <td class="py-2 px-4"><?php echo e($vehicle['battles']); ?></td>
                            <td class="py-2 px-4"><?php echo e($vehicle['frags']); ?></td>
                            <td class="py-2 px-4"><?php echo e($vehicle['damage']); ?></td>
                            <td class="py-2 px-4"><?php echo e($vehicle['wins']); ?></td>
                            <td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($vehicle['wn8'])); ?>"><?php echo e($vehicle['wn8']); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- ### Player vehicles -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wows-wn8-info\wowswn8info\resources\views/player.blade.php ENDPATH**/ ?>