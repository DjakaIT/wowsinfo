<?php
  use App\Helpers\FrontendHelper;
?>


<?php $__env->startSection('metaTitle', $metaSite['metaTitle']); ?>
<?php $__env->startSection('metaDescription', $metaSite['metaDescription']); ?>
<?php $__env->startSection('metaKeywords', $metaSite['metaKeywords']); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row mb-40">
		<div class="col">
			<iframe src="https://api.wn8.info/tools/wows/twitchlive.php" title="description" class="tw-frame"></iframe>
		</div>
	</div>
	<div class="row mb-40">
		<div class="col">
			<h2 class="heading2"> Top Player: Past 24 hours </h2>
			<div class="table-container">
				<div class="shadow4 customRedefine vehicleTable table-responsive mb-10">
					<table class="table b-table table-striped table-bordered">
						<thead>
							<tr class="bg-gray-100 text-left">
									<th class="border-b">Player</th>
									<th class="border-b">WN8</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $statistics['topPlayersLast24Hours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="border-b">
									<td class="py-2 px-4">
										<?php if(!empty($player['name']) && !empty($player['wid'])): ?>
											<a href="<?php echo e(route('player.page', ['name' => $player['name'], 'id' => $player['wid']])); ?>">
												<?php echo e($player['name']); ?>

											</a>
										<?php else: ?>
												<span>Missing name or wid</span>
										<?php endif; ?>
									</td>
									<td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($player['wn8'])); ?>"><?php echo e($player['wn8']); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<p class="table-info-para"> Statistics for players whose tier is above 5 and who have 5+ battles </p>
		</div>
		<div class="col">
			<h2 class="heading2"> Top Player: Past 7 days </h2>
			<div class="table-container">
				<div class="shadow4 customRedefine vehicleTable table-responsive mb-10">
					<table class="table b-table table-striped table-bordered">
						<thead>
							<tr class="bg-gray-100 text-left">
								<th class="border-b">Player</th>
								<th class="border-b">WN8</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $statistics['topPlayersLast7Days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="border-b">
									<td class="py-2 px-4">
										<?php if(!empty($player['name']) && !empty($player['wid'])): ?>
											<a href="<?php echo e(route('player.page', ['name' => $player['name'], 'id' => $player['wid']])); ?>">
												<?php echo e($player['name']); ?>

											</a>
										<?php else: ?>
												<span>Missing name or wid</span>
										<?php endif; ?>
									</td>
									<td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($player['wn8'])); ?>"><?php echo e($player['wn8']); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<p class="table-info-para"> Statistics for players whose tier is above 5 and who have 30+ battles </p>
		</div>
		<div class="col">
			<h2 class="heading2"> Top Player: Past month </h2>
			<div class="table-container">
				<div class="shadow4 customRedefine vehicleTable table-responsive mb-10">
					<table class="table b-table table-striped table-bordered">
						<thead>
							<tr class="bg-gray-100 text-left">
								<th class="border-b">Player</th>
								<th class="border-b">WN8</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $statistics['topPlayersLastMonth']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="border-b">
									<td class="py-2 px-4">
										<?php if(!empty($player['name']) && !empty($player['wid'])): ?>
											<a href="<?php echo e(route('player.page', ['name' => $player['name'], 'id' => $player['wid']])); ?>">
												<?php echo e($player['name']); ?>

											</a>
										<?php else: ?>
												<span>Missing name or wid</span>
										<?php endif; ?>
									</td>
									<td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($player['wn8'])); ?>"><?php echo e($player['wn8']); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<p class="table-info-para"> Statistics for players whose tier is above 5 and who have 120+ battles </p>
		</div>
	</div>
	<div class="row mb-40">
		<div class="col">
		<iframe src="https://api.wn8.info/tools/wows/ytvids.php" title="description" class="yt-frame"></iframe>
		</div>
	</div>
	<div class="row mb-10">
		<div class="col">
			<h2 class="heading2"> Top Player: Overall </h2>
			<div class="table-container">
				<div class="shadow4 customRedefine vehicleTable table-responsive mb-10">
					<table class="table b-table table-striped table-bordered">
						<thead>
							<tr class="bg-gray-100 text-left">
								<th class="border-b">Player</th>
								<th class="border-b">WN8</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $statistics['topPlayersOverall']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="border-b">
									<td class="py-2 px-4">
										<?php if(!empty($player['name']) && !empty($player['wid'])): ?>
											<a href="<?php echo e(route('player.page', ['name' => $player['name'], 'id' => $player['wid']])); ?>">
												<?php echo e($player['name']); ?>

											</a>
										<?php else: ?>
												<span>Missing name or wid</span>
										<?php endif; ?>
									</td>
									<td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($player['wn8'])); ?>"><?php echo e($player['wn8']); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<p class="table-info-para"> Statistics for players whose tier is above 5 and who have 500+ battles </p>
		</div>
		<div class="col">
			<h2 class="heading2"> Top Clans </h2>
			<div class="table-container">
				<div class="shadow4 customRedefine vehicleTable table-responsive mb-10">
					<table class="table b-table table-striped table-bordered">
						<thead>
							<tr class="bg-gray-100 text-left">
								<th class="border-b">Clan</th>
								<th class="border-b">WN8</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $statistics['topClans']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr class="border-b">
									<td class="py-2 px-4">
										<?php if(!empty($clan['name']) && !empty($clan['wid'])): ?>
											<a href="<?php echo e(route('clan.page', ['name' => $clan['name'], 'id' => $clan['wid']])); ?>">
												<?php echo e($clan['name']); ?>

											</a>
										<?php else: ?>
												<span>Missing name or wid</span>
										<?php endif; ?>
									</td>
									<td class="py-2 px-4 <?php echo e('table-' . FrontendHelper::getWN8Color($clan['wn8'])); ?>"><?php echo e($clan['wn8']); ?></td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
			<p class="table-info-para"> Statistics for clans whose tier is above 5 and who have 120+ battles </p>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wows-wn8-info\wowswn8info\resources\views/home.blade.php ENDPATH**/ ?>