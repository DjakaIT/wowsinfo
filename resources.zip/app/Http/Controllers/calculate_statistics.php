<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class calculate_statistics extends Controller
{
    //
}
