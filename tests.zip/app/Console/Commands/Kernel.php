<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        Commands\fetchAndStorePlayerShipsCommand::class,
        Commands\fetchAndStoreShipsCommand::class,
    ];

    protected function schedule(Schedule $schedule): void
    {
        $schedule->command('fetch-store:player-ships')
            ->dailyAt('02:00')
            ->appendOutputTo(storage_path('logs/Fetch_player_ships.log'));

        $schedule->command('fetch-store:ships')
            ->everyTwoMinutes()
            ->appendOutputTo(storage_path('logs/ships.log'));
    }

    protected function commands(): void
    {
        $this->load(__DIR__);
        require base_path('routes/console.php');
    }
}
