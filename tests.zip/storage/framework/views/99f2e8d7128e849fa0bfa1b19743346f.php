<footer>
  <p>&copy; <?php echo e(date('Y')); ?> wows. All rights reserved.</p>
</footer><?php /**PATH D:\wows-wn8-info\wowswn8info\resources\views/partials/footer.blade.php ENDPATH**/ ?>