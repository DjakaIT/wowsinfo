<?php $__env->startSection('metaTitle', $metaSite['metaTitle']); ?>
<?php $__env->startSection('metaDescription', $metaSite['metaDescription']); ?>
<?php $__env->startSection('metaKeywords', $metaSite['metaKeywords']); ?>

<?php $__env->startSection('content'); ?>
    <iframe src="https://api.wn8.info/tools/wows/twitchlive.php" title="description"></iframe>
    <div>
        <table class="standard-table">
            <thead>
                <tr class="bg-gray-100 text-left">
                    <th class="border-b">Player</th>
                    <th class="border-b">Wid</th>
                    <th class="border-b">WN8</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $statistics['topPlayersLast24Hours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        
                        <td class="py-2 px-4"><?php echo e($player['name']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wid']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wn8']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <table class="standard-table">
            <thead>
                <tr class="bg-gray-100 text-left">
                    <th class="border-b">Player</th>
                    <th class="border-b">Wid</th>
                    <th class="border-b">WN8</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $statistics['topPlayersLast7Days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="py-2 px-4"><?php echo e($player['name']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wid']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wn8']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <table class="standard-table">
            <thead>
                <tr class="bg-gray-100 text-left">
                    <th class="border-b">Player</th>
                    <th class="border-b">Wid</th>
                    <th class="border-b">WN8</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $statistics['topPlayersLastMonth']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="py-2 px-4"><?php echo e($player['name']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wid']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wn8']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <table class="standard-table">
            <thead>
                <tr class="bg-gray-100 text-left">
                    <th class="border-b">Player</th>
                    <th class="border-b">Wid</th>
                    <th class="border-b">WN8</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $statistics['topPlayersOverall']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="py-2 px-4"><?php echo e($player['name']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wid']); ?></td>
                        <td class="py-2 px-4"><?php echo e($player['wn8']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <table class="standard-table">
            <thead>
                <tr class="bg-gray-100 text-left">
                    <th class="border-b">Clan</th>
                    <th class="border-b">Clan Wid</th>
                    <th class="border-b">WN8</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $statistics['topClans']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="py-2 px-4"><?php echo e($clan['name']); ?></td>
                        <td class="py-2 px-4"><?php echo e($clan['wid']); ?></td>
                        <td class="py-2 px-4"><?php echo e($clan['wn8']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <iframe src="https://api.wn8.info/tools/wows/ytvids.php" title="description"></iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wows-wn8-info\wowswn8info\resources\views/home.blade.php ENDPATH**/ ?>