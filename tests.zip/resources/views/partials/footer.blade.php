<footer>
  <p>&copy; {{ date('Y') }} wows. All rights reserved.</p>
</footer>